<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 30px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 30px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        .dropdown {
            display: none;
            list-style: none;
            padding: 16px;
            position: absolute;
            top: 40px;
            background-color: black;
        }

        .dropdown a {
            display: block;
            padding: 10px;
        }

        .dropdown a:hover {
            background-color: blue;
            color: white;
        }

        .register {
            position: relative;
            display: inline-block;
        }

        .register:hover .dropdown {
            display: block;
        }

        .container {
            flex: 1; /* Pushes footer to the bottom */
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
        }

        .box {
            border: 2px solid black;
            width: 500px;
            padding: 10px;
            text-align: left;
            height: 950px;
        }

        input,
        select {
            width: 90%;
            font-size: 18px;
            margin-top: 5px;
            padding: 5px;
        }

        input[type="submit"] {
            margin-top: 20px;
            font-size: 20px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: darkblue;
        }



    </style>
</head>

<body>

    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href=".">BACK</a>
        </div>
    </div>


    <?php
    $status=$_GET['status'];
    $sid=$_GET['serviceid'];
    $cid=$_GET['customerid'];
    
    $con=mysql_connect("localhost","root","");
    mysql_select_db("event",$con);

    $sql="select * from bookmeh where status='new' and serviceid='$sid' and customerid='$cid'";
    $rs=mysql_query($sql);

    $row=mysql_fetch_array($rs);

    
?>
    <div class="container">
        <div class="box">
            <h1>UPDATE REGISTRATION:</h1>
            
            <form method="post" action="acceptstatus.php?cid=<?php echo $cid;?>">
                <label>ENTER MEHNDI TYPE:</label><br>
                <input type="text" name="mtype" value="<?php echo $row[0];?>"><br><br>

                <label>PRICE:</label><br>
                <input type="text" name="price" value="<?php echo $row[3];?>"><br><br>

                <label>CUSTOMER NAME</label><br>
                <input type="text" name="cna" readonly value="<?php echo $row[4];?>"><br><br>

                <label>CUSTOMER ADDRESS</label><br>
                <input type="text" name="add" readonly value="<?php echo $row[5];?>"><br><br>

                <label>CUSTOMER NUMBER:</label><br>
                <input type="text" name="cno" value="<?php echo $row[6];?>"><br><br>

                <label>BOOK DATE:</label><br>
                <input type="text" name="date" value="<?php echo $row[7];?>"><br><br>
                
                <label>REQUEST ID:</label><br>
                <input type="text" name="cid" value="<?php echo $row[8];?>"><br><br>

                <label>PURPOSE:</label><br>
                <input type="text" name="pur" value="<?php echo $row[9];?>"><br><br>

                <label>ACCEPT/REJECT</label>
                <select name="status">
                <option><?php echo $row[10];?></option>
                <option>NEW</option>
                <option>ACCEPT</option>
                <option>REJECT</option><br><br>     
</select>
<br><br>
<textarea rows="5" cols="25" name="mes" placeholder="message"></textarea><br><br>
                
                <input type="submit" value="U P D A T E">
            </form>
        </div>
    </div>

    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>

</body>

</html>
