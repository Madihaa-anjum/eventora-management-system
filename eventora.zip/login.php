<html>
<head>
<style>
    body 
        {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 40px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 40px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }
        .success
        {
            font-size: 30px;
            font-weight: bold;
            color: black;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 70vh; /* Adjust height to center properly */
        }
        
</style>
</head>
<body>
<div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="home.html">BACK</a>
        </div>
    </div>

    <center>
        <div class="success">
        <?php
           $name=$_POST['uname'];
           $pass=$_POST['pass'];
           session_start();

            $_SESSION['name']=$name;
            $_SESSION['pass']=$pass;
           
           $con=mysql_connect("localhost","root","");
           mysql_select_db("event",$con);

           $sql="select * from register where business_t='$name' and userid='$pass'";
           $rs=mysql_query($sql); 
           
           
           if($row=mysql_fetch_array($rs))
           {
                $s=$row['status'];
                if($s=='new')
                {
                    echo"<br> YOUR APPLICATION IS NOT YET APPROVED";
                }
                else if($s=='REJECT')
                {
                    echo"YOUR APPLICATION IS REJECTED....";
                    
                }
               else
               {
                    $b=$row['business_t'];
                    //$pass=$row['userid'];
                    if($b=='Photographer')
                    {
                        header('Location:servicephoto.php');
                    }
                    else if($b=='Event decorators')
                    {
                        header('Location:servicedecor.php');
                    }
                    else if($b=='Mehndi')
                    {
                        header('Location:servicemehndi.php');
                    
                    }
                    else
                    {
                        header('Location:serviceconv.php');
                    }


               }
           }
           else
           {
                echo"INVALID USERNAME OR PASSWORD....";
           }
       ?>
       

        
        </div>
        <br>
        <br>
    </center>
    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>
    
</body>
</html>