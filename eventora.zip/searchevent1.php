<html>
<head>
<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        background: #f0f4f7;
    }

    .header {
        background: linear-gradient(to right, #001f4d, #003366);
        color: white;
        padding: 20px 40px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .header h1 {
        margin: 0;
        font-size: 28px;
        color: white;
    }

    .nav a {
        color: white;
        text-decoration: none;
        margin: 0 15px;
        font-size: 18px;
        padding: 10px 20px;
        font-weight: bold;
        border: 2px solid white;
        border-radius: 8px;
        background-color: transparent;
        transition: all 0.4s ease-in-out;
    }

    .nav a:hover {
        background: linear-gradient(to right, #ffffff, #d4e3ff);
        color: #003366;
        transform: scale(1.05);
    }

    .footer {
        background: linear-gradient(to right, #003366, #0059b3);
        color: white;
        padding: 10px;
        text-align: center;
        margin-top: auto;
    }

    .success {
        font-size: 26px;
        font-weight: bold;
        color: #333;
        text-align: center;
        margin: 20px 0 10px 0;
    }

    h1 {
        font-size: 36px;
        font-family: Georgia, serif;
        letter-spacing: 1px;
        text-transform: uppercase;
        color: #003366;
        margin-top: 30px;
    }

    table {
        margin: 30px auto;
        border-collapse: collapse;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size: 16px;
        width: 95%;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        border-radius: 8px;
        overflow: hidden;
        border: none;
    }

    table th, table td {
        padding: 12px 16px;
        text-align: center;
        border-bottom: 1px solid #ccc;
    }

    table th {
        background-color: #004080;
        color: white;
        font-weight: 600;
    }

    table tr:nth-child(even) {
        background-color: #e6f0ff;
    }

    table tr:hover {
        background-color: #d0e4ff;
    }

    td img {
        height: 60px;
        width: 60px;
        border-radius: 8px;
        transition: transform 0.3s;
        object-fit: cover;
    }

    td img:hover {
        transform: scale(1.1);
    }
</style>
</head>
<body>

<div class="header">
    <h1>EVENTORA</h1>
    <div class="nav">
        <a href="userviewevent.php">BACK</a>
    </div>
</div>

<center><h1>Services</h1></center>

<center>
    <div class="success">
        <?php
            $t = $_POST['themes'];
            $con = mysql_connect("localhost", "root", "");
            mysql_select_db("event", $con);

            $sql = "SELECT * FROM eventdec WHERE themes ='$t'";
            $rs = mysql_query($sql);   
        ?>
        <table>
            <tr>
                <th>Business Type</th>
                <th>Name</th>
                <th>Contact Number</th>
                <th>Business Name</th>
                <th>Address</th>
                <th>Types-event</th>
                <th>Themes</th>
                <th>space-type</th>
                <th>payment</th>
                <th>images</th>
                <th>BOOK</th>
            </tr>
            <?php
                while($row = mysql_fetch_array($rs)) {
                    echo "<tr>
                        <td>{$row[0]}</td>
                        <td>{$row[1]}</td>
                        <td>{$row[2]}</td>
                        <td>{$row[3]}</td>
                        <td>{$row[4]}</td>
                        <td>{$row[6]}</td>
                        <td>{$row[7]}</td>
                        <td>{$row[8]}</td>
                        <td>{$row[9]}</td>
                        
                        <td><img src='{$row[10]}' alt='Mehndi Image'></td>
                        <td>
                        <a href='bookevent.php?userid={$row[5]}&types_event={$row[6]}&themes={$row[7]}'><img src='book.jpeg'></a>

                        </td>
                    </tr>";
                }
            ?>
        </table>
    </div>
    <br><br>
</center>

<div class="footer">
    <p>&copy; 2025 EVENTORA. ALL RIGHTS RESERVED...</p>
</div>

</body>
</html>
