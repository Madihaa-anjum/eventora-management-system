<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 30px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 30px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        .dropdown {
            display: none;
            list-style: none;
            padding: 16px;
            position: absolute;
            top: 40px;
            background-color: black;
        }

        .dropdown a {
            display: block;
            padding: 10px;
        }

        .dropdown a:hover {
            background-color: blue;
            color: white;
        }

        .register {
            position: relative;
            display: inline-block;
        }

        .register:hover .dropdown {
            display: block;
        }

        .container {
            flex: 1; /* Pushes footer to the bottom */
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
        }

        .box {
            border: 2px solid black;
            width: 700px;
            padding: 10px;
            text-align: left;
            height: 550px;
        }

        input,
        select {
            width: 90%;
            font-size: 18px;
            margin-top: 5px;
            padding: 5px;
        }

        input[type="submit"] {
            margin-top: 20px;
            font-size: 20px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: darkblue;
        }

    </style>
</head>

<body>
    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="home.html">BACK</a>
        </div>
    </div>

    <div class="container">
        <div class="box">
            <h2>CONVENTION HALL REGISTRATION:</h2>
            <form method="post" action="conv1.php">
<?php
                session_start();
                $id=$_SESSION['pass'];
?>
            

            <label>USER ID:</label><br>
                <input type="text" name="userid" value="<?php echo $id;?>">
                <br>
                <br>
          

                <label>TYPES OF EVENT ALLOWED</label><br>
                <input type="text" name="cname" placeholder="EXAMPLE:WEDDING,BIRTHDAY">
                <br>
                <br>
          

            <label>SELECT SPACE TYPE:</label><br>
                <select name="space_type">
                    <option>INDOOR</option>
                    <option>OUTDOOR</option>
                    <option>INDOOR & OUTDOOR</option>
                </select><br><br>


                <label>PAYMENT:</label><br>
                <input type="text" name="price" placeholder="ENTER YOUR EXPENSES"><br><br>

                <label>UPLOAD IMAGE OF PAST WORK</label>
                <input type="file" name="p1">

                <input type="submit" value="R E G I S T E R">
            </form>
        </div>
    </div>

    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>

</body>

</html>
