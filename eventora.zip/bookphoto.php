<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 30px;
            justify-content: space-between;
            align-items: center;
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto;
            height: 30px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        .container {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
            gap: 30px;
        }

        .box {
            border: 2px solid black;
            width: 500px;
            padding: 20px;
            background-color: #f0f0f0;
        }

        h2 {
            text-align: center;
            color: darkblue;
            font-size: 22px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
        }

        td {
            padding: 8px 0;
        }

        input[type="text"],input[type="date"]{
            width: 100%;
            font-size: 16px;
            padding: 6px;
        }

        input[type="submit"] {
            width: 48%;
            margin-top: 20px;
            font-size: 18px;
            background-color: blue;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        input[type="submit"]:hover {
            background-color: darkblue;
        }

        .buttons {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="home.html">BACK</a>
        </div>
    </div>

    <?php
        $pass = $_GET['userid'];
        $type=$_GET['types_photo'];
        $con = mysql_connect("localhost", "root", "");
        mysql_select_db("event", $con);
        $sql = "SELECT * FROM photo where userid='$pass' and types_photo='$type'";
        $rs = mysql_query($sql);
        $row = mysql_fetch_array($rs);
    ?>

    <form method="post" action="bookphoto1.php?pass=<?php echo $pass;?>">
        <div class="container">

            <!-- Booking Details Box -->
            <div class="box">
                <h2>BOOKING DETAILS</h2>
                <table>
                    <tr>
                        <td>Photography Type:</td>
                        <td><input type="text" name="ptype" value="<?php echo $row[6]; ?>"></td>
                    </tr>
                    <tr>
                        <td>Contact Number:</td>
                        <td><input type="text" name="bno" value="<?php echo $row[2]; ?>"></td>
                    </tr>
                    <tr>
                        <td>Business Name:</td>
                        <td><input type="text" name="bname" value="<?php echo $row[3]; ?>"></td>
                    </tr>
                    <tr>
                        <td>Charges:</td>
                        <td><input type="text" name="price" value="<?php echo $row[8]; ?>"></td>
                    </tr>
                </table>
            </div>

            <!-- Customer Details Box -->
            <div class="box">
                <h2>CUSTOMER DETAILS</h2>
                <table>
                    <tr>
                        <td>Your Name:</td>
                        <td><input type="text" name="name"></td>
                    </tr>
                    <tr>
                        <td>Your Address:</td>
                        <td><input type="text" name="add"></td>
                    </tr>
                    <tr>
                        <td>Contact Number:</td>
                        <td><input type="text" name="cno"></td>
                    </tr>
                    <tr>
                        <td>Booking Date:</td>
                        <td><input type="date" name="date"></td>
                    </tr>

                     <tr>
                        <td>PURPOSE:</td>
                        <td><input type="text" name="pur"></td>
                    </tr>
                </table>
                <div class="buttons">
                    <input type="submit" value="BOOK">
                    <input type="submit" value="CLEAR">
                </div>
            </div>

        </div>
    </form>

    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>

</body>
</html>
