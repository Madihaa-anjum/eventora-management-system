<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 30px;
            justify-content: space-between;
            align-items: center;
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto;
            height: 30px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        .dropdown {
            display: none;
            list-style: none;
            padding: 16px;
            position: absolute;
            top: 40px;
            background-color: black;
        }

        .dropdown a {
            display: block;
            padding: 10px;
        }

        .dropdown a:hover {
            background-color: blue;
            color: white;
        }

        .register {
            position: relative;
            display: inline-block;
        }

        .register:hover .dropdown {
            display: block;
        }

        .container {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
        }

        .box {
            border: 2px solid black;
            width: 500px;
            padding: 10px;
            text-align: left;
            height: 700px;
        }

        input,
        select {
            width: 90%;
            font-size: 18px;
            margin-top: 5px;
            padding: 5px;
        }

        input[type="submit"] {
            margin-top: 20px;
            font-size: 20px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: darkblue;
        }

    </style>

    <script>
        function registercheck() {
            let business_t = document.register.busi_type.value;
            let name = document.register.uname.value;
            let contact_num = document.register.cno.value;
            let business_n = document.register.busi.value;
            let experience = document.register.exp.value;
            let address = document.register.add.value;

            if (business_t == "") {
                alert("PLEASE SELECT BUSINESS TYPE");
                document.register.busi_type.focus();
                return false;
            } else {
                var rexp = /^[a-zA-Z ]+$/;
                if (!business_t.match(rexp)) {
                    alert("BUSINESS TYPE Should Be Alphabet...");
                    document.register.busi_type.focus();
                    return false;
                }
            }

            if (name == "") {
                alert("Please Enter Your Name");
                document.register.uname.focus();
                return false;
            } else {
                var rexp = /^[a-zA-Z ]+$/;
                if (!name.match(rexp)) {
                    alert("Name Should Be Alphabet...");
                    document.register.uname.focus();
                    return false;
                }
            }

            if (contact_num == "") {
                alert("Please Enter Contact Number");
                document.register.cno.focus();
                return false;
            } else {
                var rexp = /^[0-9]+$/;
                if (!contact_num.match(rexp)) {
                    alert("Contact number should be digits only...");
                    document.register.cno.focus();
                    return false;
                } else if (contact_num.length != 10) {
                    alert("Contact number should be 10 digits...");
                    document.register.cno.focus();
                    return false;
                }
            }

            if (business_n == "") {
                alert("Please Enter Business Name");
                document.register.busi.focus();
                return false;
            }

            if (experience == "") {
                alert("Please Enter Experience");
                document.register.exp.focus();
                return false;
            }

            if (address == "") {
                alert("Please Enter Address");
                document.register.add.focus();
                return false;
            }

            return true;
        }
    </script>
</head>

<body>

    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="home.html">BACK</a>
        </div>
    </div>

    <div class="container">
        <div class="box">
            <h1>NEW REGISTRATION:</h1>
            <form name="register" method="post" action="register.php" onsubmit="return registercheck();">
                <label>SELECT BUSINESS TYPE:</label><br>
                <select name="busi_type">
                    <option value="">-- Select --</option>
                    <option>Photographer</option>
                    <option>Mehndi</option>
                    <option>Convention hall</option>
                    <option>Event decorators</option>
                </select><br><br>

                <label>ENTER YOUR FULL NAME:</label><br>
                <input type="text" name="uname" placeholder="Enter your name"><br><br>

                <label>ENTER YOUR CONTACT NUMBER:</label><br>
                <input type="text" name="cno" placeholder="Enter contact number"><br><br>

                <label>ENTER YOUR BUSINESS NAME:</label><br>
                <input type="text" name="busi" placeholder="Enter your business name"><br><br>

                <label>ENTER YOUR EXPERIENCE:</label><br>
                <input type="text" name="exp" placeholder="Enter experience"><br><br>

                <label>ADDRESS</label><br>
                <textarea rows="5" cols="25" name="add" placeholder="Workplace address" style="width: 90%; height: 100px; font-size: 18px; padding: 5px;"></textarea><br><br>

                <input type="submit" value="R E G I S T E R">
            </form>
        </div>
    </div>

    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>

</body>
</html>
