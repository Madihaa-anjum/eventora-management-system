<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 40px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        .dropdown {
            display: none;
            list-style: none;
            padding: 0;
            margin: 0;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: black;
            z-index: 1;
        }

        .dropdown a {
            display: block;
            padding: 10px;
        }

        .dropdown a:hover {
            background-color: blue;
            color: white;
        }

        .register {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }

        .register:hover .dropdown {
            display: block;
        }

        .select-box {
            margin: 50px auto;
            display: block;
            padding: 10px 15px;
            font-size: 18px;
            font-family: 'Times New Roman', Times, serif;
            border-radius: 8px;
            border: 2px solid darkblue;
            background-color: #f9f9f9;
            color: #003366;
            box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.1);
        }

        center {
            margin-top: 40px;
            font-size: 24px;
            font-weight: bold;
            color: #003366;
        }

        /* Simple button style */
        input[type="submit"] {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            font-size: 16px;
            background-color: darkblue;
            color: white;
            border: none;
            border-radius: 5px;
        }
    </style>
     <script>
        function checkuser()
        {
            photo_type=document.psearch.p_type.value;
            if(photo_type=="")
            {
                 alert("PLEASE SELECT PHOTO TYPE:");
                 document.psearch.p_type.focus();
                return false;
            }
        }
    </script>
</head>
<body>

    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="user.php">BACK</a>
        </div>
    </div>

    <form name="psearch" method="post" action="searchphoto1.php">
        <center>SEARCH MEHNDI TYPE</center>

        <?php

  $con = mysql_connect("localhost", "root", "");
            mysql_select_db("event", $con);

            $sql = "SELECT distinct(types_photo) from photo";
            $rs = mysql_query($sql); 
?>
        <select name="p_type" class="select-box">
            <option value="">-- Select Photo Type --</option>
<?php
            while($row=mysql_fetch_array($rs))
            {
                echo "<option>".$row[0];
            }
?>
        </select>

        <input type="submit" value="SEARCH" onclick="return checkuser();">
    </form>

    <div class="footer">
        <p>&copy; 2025 EVENTORA. ALL RIGHTS ARE RESERVED...</p>
    </div>
    
</body>
</html>
