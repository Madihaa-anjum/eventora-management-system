<html>
<head>
<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        background: #f0f4f7;
    }

    .header {
        background: linear-gradient(to right, #001f4d, #003366);
        color: white;
        padding: 20px 40px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .header h1 {
        margin: 0;
        font-size: 28px;
        letter-spacing: 2px;
        color:white;
    }

    .nav a {
        color: white;
        text-decoration: none;
        margin: 0 15px;
        font-size: 18px;
        padding: 10px 20px;
        font-weight: bold;
        border: 2px solid white;
        border-radius: 8px;
        background-color: transparent;
        transition: all 0.4s ease-in-out;
    }

    .nav a:hover {
        background: linear-gradient(to right, #ffffff, #d4e3ff);
        color: #003366;
        transform: scale(1.05);
    }

    h1 {
        font-size: 36px;
        font-family: Georgia, serif;
        letter-spacing: 1px;
        text-transform: uppercase;
        color: #003366;
        margin: 30px auto 20px auto;
        text-align: center;
    }

    .success {
        font-size: 26px;
        font-weight: bold;
        color: #333;
        text-align: center;
        margin: 20px 0;
    }

    table {
        margin: 30px auto;
        border-collapse: collapse;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size: 16px;
        width: 95%;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        border-radius: 8px;
        overflow: hidden;
    }

    table th, table td {
        padding: 12px 16px;
        text-align: center;
        border-bottom: 1px solid #ccc;
    }

    table th {
        background-color: #004080;
        color: white;
    }

    table tr:nth-child(even) {
        background-color: #e6f0ff;
    }

    table tr:hover {
        background-color: #d0e4ff;
    }

    td img {
        height: 50px;
        width: 50px;
        border-radius: 8px;
        transition: transform 0.3s;
        object-fit: cover;
    }

    td img:hover {
        transform: scale(1.1);
    }

    .footer {
        background: linear-gradient(to right, #003366, #0059b3);
        color: white;
        padding: 10px;
        text-align: center;
        margin-top: auto;
    }
</style>
</head>
<body>

<div class="header">
    <h1>EVENTORA</h1>
    <div class="nav">
        <a href="servicedecor.php">BACK</a>
    </div>
</div>

<h1>New Business Registrations</h1>

<div class="success">
    <?php
     //session_start();
        $pass=$_GET['pass'];
        $bookd=$_POST['booking_date'];
        $con = mysql_connect("localhost", "root", "");
        mysql_select_db("event", $con);

       $sql = "SELECT * FROM bookevent WHERE date(bookdate)='$bookd' and serviceid='$pass' and status='Accept'";
        $rs = mysql_query($sql); 
          
    ?>
    <table>
        <tr>
            <th>SERVICEID</th>
            <th>EVENT TYPE</th>
             <th>THEMES</th>
            <th>PRICE</th>
            <th>CUSTOMER NAME</th>
            <th>CUSTOMER ADDRESS</th>
            <th>CUSTOMER CNUMBER</th>
            <th>BOOK DATE</th>
            <th>CUSTOMER ID</th>
            <th>PURPOSE</th>
            <th>STATUS</th>
            <th>ACCEPT/REJECT</th>

        </tr>
        <?php
            while($row = mysql_fetch_array($rs)) {
                echo "<tr>
                        <td>{$row[12]}</td>
                        <td>{$row[0]}</td>
                        <td>{$row[1]}</td>  
                        <td>{$row[4]}</td>
                        <td>{$row[5]}</td>
                        <td>{$row[6]}</td>
                        <td>{$row[7]}</td>
                        <td>{$row[8]}</td>
                        <td>{$row[9]}</td>
                        <td>{$row[10]}</td>
                        <td>{$row[11]}</td>
                        <td><a href='acceptevent1.php?status={$row[11]}&serviceid={$row[12]}&customerid={$row[9]}'><img src='u.jpeg' alt='Update'></a></td>
                    </tr>";
            }
        ?>
    </table>
</div>

<div class="footer">
    <p>&copy; 2025 EVENTORA. All rights reserved.</p>
</div>

</body>
</html>
