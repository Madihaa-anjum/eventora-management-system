<html>
<head>
<style>
    body 
        {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 40px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 40px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }
        .success
        {
            font-size: 30px;
            font-weight: bold;
            color: black;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 70vh; /* Adjust height to center properly */
        }
        
</style>
</head>
<body>
<div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="home.html">HOME</a>
            <a href="admin.html">ADMIN</a>
            <a href="about.html">ABOUT</a>
        </div>
    </div>

    <center>
        <div class="success">
        <?php
            $n=$_POST['uname'];
            $p=$_POST['pass'];

            if($n=="")
            {
                echo "<br> please enter user name";
            }
            else if($p=="")
            {
                echo "<br> please enter password";
            }
            else if($n=="admin" && $p=="9035247527")
            {
                echo "<br> valid user account";
                header('location:view.html');
            }
            else
            {
                echo "<br> INVALID USER ACCOUNT";
            }
        ?>
        </div>
        <br>
        <br>
    </center>
    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>
    
</body>
</html>