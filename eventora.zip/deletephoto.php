<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 30px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 30px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        .dropdown {
            display: none;
            list-style: none;
            padding: 16px;
            position: absolute;
            top: 40px;
            background-color: black;
        }

        .dropdown a {
            display: block;
            padding: 10px;
        }

        .dropdown a:hover {
            background-color: blue;
            color: white;
        }

        .register {
            position: relative;
            display: inline-block;
        }

        .register:hover .dropdown {
            display: block;
        }

        .container {
            flex: 1; /* Pushes footer to the bottom */
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
        }

        .box {
            border: 2px solid black;
            width: 500px;
            padding: 10px;
            text-align: left;
            height: 900px;
        }

        input,
        select {
            width: 90%;
            font-size: 18px;
            margin-top: 5px;
            padding: 5px;
        }

        input[type="submit"] {
            margin-top: 20px;
            font-size: 20px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: darkblue;
        }


    </style>
</head>

<body>

    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="home.html">BACK</a>
        </div>
    </div>


    <?php

    $serviceid=$_GET['userid'];
    $photo_t=$_GET['types_photo'];

    //echo "<br> UPDATING".$cno."Details";

    $con=mysql_connect("localhost","root","");
    mysql_select_db("event",$con);

    $sql="select * from photo where userid='$serviceid' and types_photo='$photo_t'";
    $rs=mysql_query($sql);

    $row=mysql_fetch_array($rs);

    
?>
    <div class="container">
        <div class="box">
            <h1>UPDATE REGISTRATION:</h1>
            <form method="post" action="deletephotostatus.php?serviceid=<?php echo $serviceid;?> & types_photo=<?php echo $photo_t;?>">
                <label>BUSINESS TYPE:</label><br>
                <select name="busi_type">
                    <option><?php echo $row[0];?></option>
                </select><br><br>

                <label> FULL NAME:</label><br>
                <input type="text" name="uname" readonly value="<?php echo $row[1];?>"><br><br>

                <label>CONTACT NUMBER:</label><br>
                <input type="text" name="cno"  readonly value="<?php echo $row[2];?>"><br><br>

                <label>BUSINESS NAME:</label><br>
                <input type="text" name="busi" readonly value="<?php echo $row[3];?>"><br><br>

                <label>ADDRESS :</label><br>
                <input type="text" name="add" readonly value="<?php echo $row[4];?>"><br><br>

                <label>SERVICE ID:</label><br>
                <input type="text" name="id" readonly value="<?php echo $row[5];?>"><br><br>

                <label>PHOTO TYPE:</label><br>
                <input type="text" name="photo" readonly value="<?php echo $row[6];?>"><br><br>

                <label>CHARGES:</label><br>
                <input type="text" name="charges" value="<?php echo $row[8];?>"><br><br>

                <label>IMAGES:</label><br>
                <input type="file" name="image" value="<?php echo $row[9];?>"><br><br>

</select>
                
                <input type="submit" value="D E L E T E">
            </form>
        </div>
    </div>

    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>

</body>

</html>
