<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 40px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        .image-section {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 30px 20px 100px; /* bottom padding for footer */
        }

        .card {
            width: 300px;
            text-align: center;
        }

        .card img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }

        .card button {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: darkblue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .card button:hover {
            background-color: black;
        }
    </style>
</head>
<body>


    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="home.html">BACK</a>
        </div>
    </div>

    <div style="padding: 20px;">
        <h2>WELCOME TO OUR EVENTORA!</h2>
        <p>- WHERE EVERY MOMENT BECOMES A CELEBRATION</p>
    </div>

    <div class="image-section">
        <div class="card">
            <a href="userviewmehndi.php"><img src="mehndi.jpeg" alt="Mehndi"></a>
            <a href="userviewmehndi.php"><button>VIEW MEHNDI</button></a>
            
        </div>
        <div class="card">
            <a href="userviewphoto.php"><img src="photo.jpeg" alt="Photographer"></a>
            <a href="userviewphoto.php"><button>VIEW PHOTOGRAPHER</button></a>
        </div>
        <div class="card">
            <a href="userviewevent.php"><img src="event.jpeg" alt="Event Decorator"></a>
            <a href="userviewevent.php"><button>VIEW EVENT</button></a>
        </div>
        <div class="card">
           <a href="userviewconv.php"> <img src="convention.jpeg" alt="Convention Hall"></a>
            <a href="userviewconv.php"><button>VIEW CONVENTION</button></a>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2025 EVENTORA. ALL RIGHTS ARE RESERVED...</p>
    </div>
    
</body>
</html>
