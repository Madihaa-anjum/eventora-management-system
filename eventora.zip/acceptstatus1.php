<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 30px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 30px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }
        .nav a:hover {
            background-color: black;
        }
        .success
        {
            font-size: 30px;
            font-weight: bold;
            color: black;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 70vh; /* Adjust height to center properly */
        }

    </style>
</head>

<body>

    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="servicemehndi.php">BACK</a>
        </div>
    </div>

    <div class="success">
    <?php

    $status=$_POST['status'];
    $customer_id=$_GET['cid'];
    $message=$_POST['add'];
    

    $con=mysql_connect("localhost","root","");
    mysql_select_db("event",$con);

    
$sql="update bookmeh set status='$status' where customerid='$customer_id'";
//$sql1="insert into bookmeh values('$message')" ;
mysql_query($sql);
    echo "status upadted successfully..."
?>
</div>
     <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>

</body>

</html>
