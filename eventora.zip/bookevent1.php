<html>
<head>
<style>
    body 
        {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 40px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 40px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }
        .success
        {
            font-size: 30px;
            font-weight: bold;
            color: black;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 70vh; /* Adjust height to center properly */
        }
        
</style>
</head>
<body>
<div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="userviewevent.php">BACK</a>
        </div>
    </div>

    <center>
        <div class="success">
        <?php
            $pass = $_GET['pass'];
            $event_type=$_POST['etype'];
            $themes=$_POST['theme'];
            $cno=$_POST['bno'];
            $busi_name=$_POST['bname'];
            $price=$_POST['price'];
            $cname=$_POST['name'];
            $cadd=$_POST['add'];
            $cuno=$_POST['cno'];
            $bookdate=$_POST['date'];
            $purpose=$_POST['pur'];

            $con=mysql_connect("localhost","root","");

            mysql_select_db("event",$con);


            $rs=mysql_query("select * from  bookingid");
            $row=mysql_fetch_array($rs);
            $id=$row[0];
            $cpass=$cname[0].$id.$cname[3];

            $sql="insert into bookevent values('$event_type','$themes','$cno','$busi_name','$price','$cname','$cadd','$cuno','$bookdate','$cpass','$purpose','new','$pass','','','')";
            mysql_query($sql);

            $id=$id+2;
            mysql_query("update bookingid set id ='$id'");
            echo "<br><br> REGISTERED SUCCESSFULLY....=$cpass";
        ?>
        </div>
        <br>
        <br>
    </center>
    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>
    
</body>
</html>