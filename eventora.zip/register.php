<html>
<head>
<style>
    body 
        {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 40px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 40px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }
        .success
        {
            font-size: 30px;
            font-weight: bold;
            color: black;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 70vh; /* Adjust height to center properly */
        }
        
</style>
</head>
<body>
<div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="home.html">HOME</a>
            <a href="login.html">LOGIN</a>
            <a href="register1.php">BACK</a>
        </div>
    </div>

    <center>
        <div class="success">
        <?php
            $b=$_POST['busi_type'];
            $name=$_POST['uname'];
            $cno=$_POST['cno'];
            $busi_name=$_POST['busi'];
            $exp=$_POST['exp'];
            $add=$_POST['add'];

            $con=mysql_connect("localhost","root","");

            mysql_select_db("event",$con);


            $rs=mysql_query("select * from idcount");
            $row=mysql_fetch_array($rs);
            $id=$row[0];
            $pass=$name[0].$id.$name[3];

            $sql="insert into register values('$b','$name','$cno','$busi_name','$exp','new','$pass','$add')";
            mysql_query($sql);

            $id=$id+2;
            mysql_query("update idcount set cnt ='$id'");
            echo "<br><br> REGISTERED SUCCESSFULLY....=$pass";
        ?>
        </div>
        <br>
        <br>
    </center>
    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>
    
</body>
</html>