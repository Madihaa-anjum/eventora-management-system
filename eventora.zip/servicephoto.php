<html>
    <head>
        <style>
        body{
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
        }
        .header{
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .footer{
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
        .nav a{
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }
        .nav a:hover{
            background-color:black;
        }
        .dropdown {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: black;
            z-index: 1;
            padding: 0;
            margin: 0;
            list-style: none;
}

        .dropdown a
        {
           display: block;
           padding: 10px; 
        }
        
        .dropdown a:hover
        {
            background-color:blue;
            color:white;
        }
        .register
        {
            position: relative;
            display: inline-block;
        }
        .register:hover .dropdown
        {
            display: block;
        }
        </style>
        </head>
<body>
<?php
    session_start();
    $pass=$_SESSION['pass'];
    
?>
    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            

            <div class="register">
                <a href="#register">SERVICE</a>
                <div class="dropdown">
                    <a href="photographer.php">ADD SERVICE</a>
                    <a href="photoview.php?pass=<?php echo $pass;?>">VIEW </a>
                </div>
            </div>


            <div class="register">
                <a href="#VIEW">VIEW ORDERS</a>
                <div class="dropdown">
                    <a href="neworderphoto.php?pass=<?php echo $pass;?>">NEW ORDERS</a>
                    <a href="viewacceptphoto.php?pass=<?php echo $pass;?>">ACCEPTED</a>
                    <a href="completedphoto.php?pass=<?php echo $pass;?>">COMPLETED</a>

                    <a href="acceptphototoday.php?pass=<?php echo $pass;?>">TODAY-ACCEPTED</a>
                    <a href="completedphototoday.php?pass=<?php echo $pass;?>">TODAY-COMPLETED</a>

                </div>
            </div>

            <div class="register">
                <a href="#search">SEARCH</a>
                <div class="dropdown">
                    <a href="searchtodayphoto.php?pass=<?php echo $pass;?>">SEARCH  ON TODAY</a>
                    <a href="searchondatephoto.php?pass=<?php echo $pass;?>">SEARCH ON DATE</a>
                </div>
            </div>
            <a href="home.html">BACK</a>
            
        </div>
    </div>


    <div style="padding: 20px;">
        <h2> WELCOME TO OUR EVENTORA!</h2>
        <p>-WHERE EVERY MOMENT BECOMES A CELEBRATION</p>
        </div>
 
     
    
        <div class="footer">
            <p>$copy;2025 EVENTORA.ALL RIGHTS ARE RESERVED...</p>
        </div>
</body>
</html>