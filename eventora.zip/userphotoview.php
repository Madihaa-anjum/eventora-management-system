<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 40px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        center {
            margin-top: 40px;
            font-size: 24px;
            font-weight: bold;
            color: #003366;
        }

        .input-box {
            margin: 50px auto 20px;
            display: block;
            padding: 10px 15px;
            font-size: 18px;
            font-family: 'Times New Roman', Times, serif;
            border-radius: 8px;
            border: 2px solid darkblue;
            background-color: #f9f9f9;
            color: #003366;
            box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        input[type="submit"] {
            display: block;
            margin: 0 auto 50px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: darkblue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: black;
        }
    </style>
     <script>
        function checkuser()
        {
            cusid=document.psearch.cid.value;
            if(cusid=="")
            {
                 alert("PLEASE ENTER CUSTOMER ID:");
                 document.psearch.cid.focus();
                return false;
            }
        }
    </script>
</head>
<body>

<div class="header">
    <h1>EVENTORA</h1>
    <div class="nav">
        <a href="home.html">BACK</a>
    </div>
</div>

<form  name="psearch" method="post" action="usersearchphoto.php">
    <center>SEARCH PHOTOGRAPHY BOOKING BY USER ID</center>

    <input type="text" name="cid" class="input-box" placeholder="Enter User ID" >

    <input type="submit" value="SEARCH" onclick="return checkuser();">
</form>

<div class="footer">
    <p>&copy; 2025 EVENTORA. ALL RIGHTS ARE RESERVED...</p>
</div>

</body>
</html>
