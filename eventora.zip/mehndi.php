<html>
<head>
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: darkblue;
            color: white;
            padding: 15px;
            display: flex;
            height: 30px;
            justify-content: space-between;
            align-items: center;
        
        }

        .footer {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: auto; /* Space between form and footer */
            height: 30px;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 20px;
        }

        .nav a:hover {
            background-color: black;
        }

        .dropdown {
            display: none;
            list-style: none;
            padding: 16px;
            position: absolute;
            top: 40px;
            background-color: black;
        }

        .dropdown a {
            display: block;
            padding: 10px;
        }

        .dropdown a:hover {
            background-color: blue;
            color: white;
        }

        .register {
            position: relative;
            display: inline-block;
        }

        .register:hover .dropdown {
            display: block;
        }

        .container {
            flex: 1; /* Pushes footer to the bottom */
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
        }

        .box {
            border: 2px solid black;
            width: 700px;
            padding: 10px;
            text-align: left;
            height: 550px;
        }

        input,
        select {
            width: 90%;
            font-size: 18px;
            margin-top: 5px;
            padding: 5px;
        }

        input[type="submit"] {
            margin-top: 20px;
            font-size: 20px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: darkblue;
        }

    </style>
    <script>
    function check()
	{
		mehndi_t=document.mehndi.mname.value;
        service=document.mehndi.serv.value;
        payment=document.mehndi.price.value;
		image=document.mehndi.p1.value;

		if(mehndi_t=="")
		{
			alert("Please Enter Mehndi Type");
			document.mehndi.mname.focus();	
			return false;
		}
		else
		{
			var rexp=/^[a-zA-Z ]+$/;

			if(!document.mehndi.mname.value.match(rexp))
			{
				alert(" Mehndi type Should Be Alphabet...");
				document.mehndi.mname.focus();
				return false;
			}

		}

		if(service=="")
		{
			alert("Please Enter Home Service");
			document.mehndi.serv.focus();	
			return false;
		}
		else
		{
			var rexp=/^[a-zA-Z ]+$/;

			if(!document.mehndi.serv.value.match(rexp))
			{
				alert(" Services Should Be Alphabet...");
				document.mehndi.serv.focus();
				return false;
			}
		}

        if(payment=="")
		{
			alert("Please Enter Amount");
			document.mehndi.price.focus();	
			return false;
		}
		
        if(image=="")
		{
			alert("Please Enter image");
			document.mehndi.p1.focus();	
			return false;
		}
		
		}


    </script>
</head>

<body>
    <div class="header">
        <h1>EVENTORA</h1>
        <div class="nav">
            <a href="servicemehndi.php">BACK</a>
        </div>
    </div>

    <div class="container">
        <div class="box">
            <h2>MEHNDI ARTIST REGISTRATION:</h2>
            
            <form name="mehndi" method="post" action="mehndi1.php">
            <?php
                session_start();
                $id=$_SESSION['pass'];
            ?>
            
            <label>userid:</label><br>
            <input type="text" name="userid" value="<?php echo $id;?>">
            <br>
            <br>

                <label>TYPES OF MEHNDI:</label><br>
                <input type="text" name="mname" placeholder="EXAMPLE:BRIDAL,NON-BRIDAL, ETC..,">
                <br>
                <br>

                <label>DO YOU PROVIDE HOME SERVICES:</label><br>
                <input type="text" name="serv" placeholder="yes or no">
                <br>
                <br>
            
                <label>PAYMENT:</label><br>
                <input type="text" name="price" placeholder="EXAMPLE:FOR BRIDAL 10000"><br><br>

                <label>UPLOAD IMAGE</label>
                <input type="file" name="p1">

                <input type="submit" value="R E G I S T E R" onclick="return check();">
                
            </form>
        </div>
    </div>

    <div class="footer">
        <p>&copy;2025 EVENTORA. ALL RIGHTS RESERVED...</p>
    </div>

</body>

</html>
